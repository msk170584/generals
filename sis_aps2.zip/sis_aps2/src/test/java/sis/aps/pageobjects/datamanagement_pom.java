package sis.aps.pageobjects;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class datamanagement_pom{
	
	public WebDriver ldriver;

	public datamanagement_pom(WebDriver rdriver) {
		
		ldriver=rdriver;
		PageFactory.initElements(rdriver, this);
	}
	
	@FindBy(xpath="//span[@class='menu-text' and text()='Dashboard']//following::span[2]") WebElement clkDataMgmt;
	public void clkDataMgmt()
	{
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkDataMgmt);
		//clkDataMgmt.click();
	}
	@FindBy(xpath="//span[@class='menu-text' and text()='Excel importhdfhdfdf']") WebElement clkExcel;
	public void clkExcelSheet()
	{  
		JavascriptExecutor js=(JavascriptExecutor) ldriver;
		js.executeScript("arguments[0].click()", clkExcel);
		//clkExcel.click();
	}
	@FindBy(xpath="//body/app-layout[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/app-job-excel-import[1]/app-excel-upload[1]/mat-accordion[1]/mat-expansion-panel[1]/div[1]/div[1]/div[1]/div[1]/div[1]/mat-form-field[1]/div[1]/div[1]/div[1]/mat-select[1]/div[1]/div[2]/div[1]") WebElement clkEntitylist;
	public void clkEntitydropdown()
	{
		//js.executeScript("arguments[0].click()", clkEntitylist);
		clkEntitylist.click();
	}
	@FindBy(xpath="//body/div[1]/div[2]/div[1]/div[1]/div[1]/mat-option[3]/span[1]") WebElement clkEntityName;
	public void clkEntityNameoption()
	{
		//js.executeScript("arguments[0].click()", clkEntityName);
		clkEntityName.click();
	}
	@FindBy(xpath="//span[text()='Download excel template']") WebElement clkDownload;
	public void clkDownloadbtn()
	{
		//js.executeScript("arguments[0].click()", clkDownload);
		clkDownload.click();
	}

}
