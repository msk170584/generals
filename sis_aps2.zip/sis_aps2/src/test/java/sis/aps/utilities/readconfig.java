package sis.aps.utilities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class readconfig {
	
	Properties prop=new Properties();
	
	public readconfig() {
		
		try {
		FileInputStream source=new FileInputStream(System.getProperty("user.dir")+"/configuration/config.properties");
		prop.load(source);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public String getappurl()
	{
		String url=prop.getProperty("baseurl");
		return url;
	}
	public String getbrowser()
	{
		String browserpath=prop.getProperty("chromepath");
		return browserpath;
	}
	public String getusername()
	{
		String login=prop.getProperty("username");
		return login;
	}
	public String getpassword()
	{
		String password=prop.getProperty("password");
		return password;
	}

}

