package sis.aps.testcases;

import org.testng.Assert;
import org.testng.annotations.Test;
import sis.aps.pageobjects.datamanagement_pom;
import sis.aps.pageobjects.loginpage_pom;

public class tc02_Datamanagement extends baseclass{
		
	@Test
	public void datamanagment() throws InterruptedException
	{	
		loginpage_pom login=new loginpage_pom(driver);
		Thread.sleep(3000);
		login.setUserName(username);
		login.setPasword(password);
		Thread.sleep(3000);
		login.clkSignin();
		Thread.sleep(3000);

		datamanagement_pom dm=new datamanagement_pom(driver);
		Thread.sleep(3000);
		dm.clkDataMgmt();
		logger.info("On DataManagement Tab");
		Thread.sleep(3000);
		dm.clkExcelSheet();
		logger.info("On Excel Sheet Tab");
		Thread.sleep(3000);
		System.out.println(driver.getCurrentUrl());
		if(driver.getCurrentUrl().equals("https://apswebqa.azurewebsites.net/data-management/excel-import"))
		{
			Assert.assertTrue(true);
			logger.info("Successfully landed in Datamanagement Excel Screen");
		}
		else
		{
			Assert.fail();
			logger.info("Page not landed in Datamanagement Excel Screen");
		}
		Thread.sleep(5000);
		login.clkicon();
		login.clkSignout();
		logger.info("Logout Successfully");
	}

}
