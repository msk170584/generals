package sis.aps.testcases;

import org.testng.annotations.Test;
import sis.aps.pageobjects.datamanagement_pom;
import sis.aps.pageobjects.loginpage_pom;

public class tc03_DM_EntityDownload extends baseclass {
	
	@Test
	public void entitynamedownload() throws InterruptedException
	{
		loginpage_pom login=new loginpage_pom(driver);
		Thread.sleep(3000);
		login.setUserName(username);
		login.setPasword(password);
		Thread.sleep(3000);
		login.clkSignin();
		Thread.sleep(3000);
		
		datamanagement_pom dm=new datamanagement_pom(driver);
		Thread.sleep(3000);
		logger.info("Clicked on DataManagement Tab");
		dm.clkDataMgmt();
		Thread.sleep(3000);
		logger.info("Clicked on Excel Sheet Tab");
		dm.clkExcelSheet();
		Thread.sleep(3000);
		
		dm.clkEntitydropdown();
		logger.info("Entity Dropdown clicked");
		Thread.sleep(3000);
		dm.clkEntityNameoption();
		logger.info("Entity Name Selected");
		Thread.sleep(3000);
		dm.clkDownloadbtn();
		logger.info("Entity Downloaded");
		Thread.sleep(5000);
		
		login.clkicon();
		login.clkSignout();
		logger.info("Logout Successfully");
	}

}
