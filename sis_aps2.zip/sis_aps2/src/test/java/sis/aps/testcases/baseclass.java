package sis.aps.testcases;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;

import sis.aps.pageobjects.loginpage_pom;
import sis.aps.utilities.readconfig;

public class baseclass{
	
	public static WebDriver driver;
	public static Logger logger;
	
	
	readconfig rd=new readconfig();
	public String baseurl=rd.getappurl();
	public String browser=rd.getbrowser();
	public String username=rd.getusername();
	public String password=rd.getpassword();
	
	@BeforeClass
	public void setup() throws InterruptedException
	{
		logger=Logger.getLogger(getClass());
		PropertyConfigurator.configure("log4j.properties");
		logger.info("Browser Launched");
		System.setProperty("webdriver.chrome.driver", browser);
		ChromeOptions options=new ChromeOptions();
		options.setHeadless(true);
		driver=new ChromeDriver(options);
		//driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		logger.info("Invoked Application URL");
		driver.get(baseurl);
		Thread.sleep(6000);
        //JavascriptExecutor js=(JavascriptExecutor) driver;
		//WebElement signin=driver.findElement(By.xpath("//button[@id='kt_login_signin_submit']"));
		//js.executeScript("arguments[0].click()", signin);
		driver.findElement(By.xpath("//button[@id='kt_login_signin_submit']")).click();
		logger.info("Login Credential Page accessed");
	}
	@AfterClass
	public void closebrowser()
	{
		driver.close();
		logger.info("Browser Closed");
	}
	@AfterMethod
	public void capturescreenshots(ITestResult result) throws IOException
	{
		if(result.getStatus()==ITestResult.FAILURE)
		{
			TakesScreenshot ts=(TakesScreenshot) driver;
			File source=ts.getScreenshotAs(OutputType.FILE);
			File target=new File(System.getProperty("user.dir")+"/screenshots/"+result.getName()+".png");
			FileUtils.copyFile(source, target);
		}
	}

}
