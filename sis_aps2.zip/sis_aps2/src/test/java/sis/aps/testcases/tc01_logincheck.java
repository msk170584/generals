package sis.aps.testcases;

import org.testng.Assert;
import org.testng.annotations.Test;

import sis.aps.pageobjects.loginpage_pom;

public class tc01_logincheck extends baseclass {
	
	@Test
	public void logintest() throws InterruptedException
	{
		loginpage_pom login=new loginpage_pom(driver);
		Thread.sleep(3000);
		login.setUserName(username);
		login.setPasword(password);
		Thread.sleep(5000);
		login.clkSignin();
		Thread.sleep(6000);
		if(driver.getTitle().equals("SIS APS"))
		{
			Assert.assertTrue(true);
			logger.info("Logged in Successfully");
		}
		else
		{
			Assert.fail();
			logger.info("Login failed");
		}
		Thread.sleep(10000);
		//login.clkicon();
		//login.clkSignout();
		//logger.info("Logout Successfully");
		
	}
	
	

}
